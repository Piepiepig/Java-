import java.util.Random;
public class Main
{
	public static void main(String[] args) {
	 Random random = new Random();  
	 int min = 7;
	 int max = 91;
	 int num = random.nextInt((max - min)+ 1)+ min; 
	System.out.println(num);
	
	    
	    
	    
	    
	    
	    
	    
	    
	    
	}
}