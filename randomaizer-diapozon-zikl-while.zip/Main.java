import java.util.Random;
public class Main
{
	public static void main(String[] args) {
	 Random random = new Random();  
	 int min=3;
	 int max= 1000;
	 int i = 0;
    while(i<1000){
	    int number =random.nextInt((max-min) + 1)+ min;
	    System.out.println(number);
	    
	   i++ ;
	}
	
	    
	    
	    
	    
	    
	    
	    
	    
	    
	}
}
